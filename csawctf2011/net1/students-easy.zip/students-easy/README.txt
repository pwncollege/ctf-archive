﻿
Like any good university student, you come across a desktop PC being thrown on the street,
and rescue it from it's grim fate.  Upon inspection you find a piece of software operating 
in a small niche software market - ripe for exploitation.

In fact, you're super lucky because this wasn't a client - it was a server.  A server that 
presumably openly listens on the internet.  And may be open to remotely exploitable bugs.
And what's more - you hit the jackpot.  Dozens of dump files for the server.  You don't even 
need to fuzz it, just check out these coredumps and there're your bugs!  

There's just one hitch: the corefiles are encrypted.  Apparently the server catches its 
crash, takes a dump of itself, and encrypts the dump for transmitting home for developers 
to analyze.

After poking around a bit, you find a commandline tool called 'DumpPrepper' that takes a 
filename on the commandline and seems to encrypt it.  

Reverse engineer the program, decrypt the dumpfile.