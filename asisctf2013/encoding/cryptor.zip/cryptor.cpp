#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

using namespace std;
int bitXor(int, int);

int main(int argc, char **argv)
{
	srand(time(NULL));
	char *path=new char[30];
	if(argc > 1)
		path = argv[1];
	else
	{
		printf("\nenter file\n");
		scanf("%s",path);
	}
	int g = rand() % 512 + 32;
	int n = rand() % g;
	int mask = rand() % 256;
	FILE *inFile = fopen(path, "rb");
	FILE *outFile = fopen(strcat(path, "_Crypted"), "wb");
	if(inFile == NULL || outFile == NULL)
	{
		printf("Error\ncant read/write file\n");
		return 1;
	}
	unsigned char H, L;
	unsigned char *readBuffer = new unsigned char[g], *writeBuffer = new unsigned char[g];
	while(!feof(inFile))
	{
		int len = fread(readBuffer, 1, g, inFile);
		if(len < g)
			fwrite(readBuffer , 1 , len , outFile);
		else
		{
			for(int i = 0 ; i < g ; i++)
			{
				int nIndex = i + n;
				int pIndex = i - n;
				if(nIndex >= g) 
					nIndex -= g;
				if(nIndex < 0) 
					nIndex += g;
				if(pIndex >= g) 
					pIndex -= g;
				if(pIndex < 0) 
					pIndex += g;
				H = readBuffer[nIndex] / 16;
				L = readBuffer[pIndex] % 16;
				writeBuffer[i] = bitXor(16 * H + L, mask);
			}
			fwrite(writeBuffer , 1 , g , outFile);
		}
	}
	fclose (inFile);
	fclose (outFile);
	printf("\nsave decryption code: %d.%d.%d\n", g, n, mask);
	return 0;
}

int bitXor(int x, int y)
{
    int a = x & y;
    int b = ~x & ~y;
    int z = ~a & ~b;
    return z;
}
